import React from 'react';
import { Filter, SelectInput,SelectArrayInput, SelectField, ChipField, BooleanField, BooleanInput, EmailInput, NumberInput, NumberField, List, Datagrid, TextField, EmailField, ReferenceField, DateField, URLField, EditButton, Create, SimpleForm, TextInput, DateInput, ReferenceInput } from 'react-admin';
import { MyUrlField } from './MyUrlField';
import PasswordInput from 'material-ui-password-field';

const UserFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Search" source="username" alwaysOn />
        {/* <ReferenceInput label="Keyword_name" source="Keyword_name" reference="keyword_name" allowEmpty>
            <SelectInput optionText="name" />
        </ReferenceInput> */}
    </Filter>
);
export const UserList = props => (
    <List filters={<UserFilter />} {...props}>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="username" />
            <EmailField source="email" />
            <TextField source="provider" />
            <BooleanField source="confirmed" />
            <BooleanField source="blocked" />
            <NumberField source="role.id" />
            <TextField source="role.name" />
            <TextField source="role.description" />
            <TextField source="dateOfBirth" />
            <TextField source="joiningDate" />
            <TextField source="firstName" />
            <EditButton />
        </Datagrid>
    </List>
);

export const UserCreate = props => (
    <Create {...props}>
        <SimpleForm>
        <TextField source="id" />
            <TextInput source="username" required />
            <TextInput source="email" type="email" required />
            {/* <PasswordInput source="password" /> */}
            <TextInput label="Password" source="password" type="password" required />
            <TextInput source="provider" />
            <BooleanInput source="confirmed" />
            <BooleanInput source="blocked" />
            {/* <NumberInput source="role.id" required /> */}
            <SelectInput source="role" choices={[
                { id: '1', name: "Administrator" },
                { id: '2', name: "Authenticated" },
                { id: '3', name: "Public"},
            ]} />
            <DateInput source="dateOfBirth" />
            <DateInput source="joiningDate" />
            <TextInput source="firstName" />
        </SimpleForm>
    </Create>
);