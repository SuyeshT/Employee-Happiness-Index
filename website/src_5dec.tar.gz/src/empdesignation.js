import React from 'react';
import { Filter, List, Datagrid, TextField, ReferenceField, DateField, EditButton, ReferenceInput, TextInput, SimpleForm, Create } from 'react-admin';

const EmpdesignationFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Search" source="designation" alwaysOn />
    </Filter>
);



export const EmpdesignationList = props => (
    <List filters={<EmpdesignationFilter />} {...props}>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="designation" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            <ReferenceField source="empdesignation_id" reference="empdesignations"><TextField source="id" /></ReferenceField>
            <EditButton />
        </Datagrid>
    </List>
);


export const EmpdesignationCreate = props => (
    <Create {...props}>
        <SimpleForm>
        <TextInput source="id" />
        <TextInput source="designation" />
        <DateField source="created_at" />
        <DateField source="updated_at" />
        {/* <ReferenceInput source="empdesignation_id" reference="empdesignations"><TextField source="id" /></ReferenceInput> */}
        </SimpleForm>
    </Create>
);