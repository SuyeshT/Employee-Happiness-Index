import { AUTH_LOGIN, AUTH_LOGOUT, AUTH_ERROR, AUTH_GET_PERMISSIONS, AUTH_CHECK } from 'react-admin';
// import * as constants from '../Constants/Constants'
import Cookies from 'js-cookie'

export default (type, params) => {
    if(type === AUTH_LOGIN){
        const {username , password} = params;
        const dataToSendForRequest = {"identifier":username,"password":password}

        const request = new Request('http://192.168.2.87:1337/auth/local', {
            method: 'POST',
            body: JSON.stringify(dataToSendForRequest),
            headers: new Headers({ 'Content-Type': 'application/json' }),
        })   
        return fetch(request)
            .then(response => {
                if (response.status < 200 || response.status >= 300) {
                    
                    throw new Error("Wrong username or password",response.statusText);
                }
                return response.json();
            })
            .then((data) => {
              if( data.user.role.name === "Authenticated"){
                alert("role = admin");
                
              }
               if(data.user.role.name ==="Public"){
                alert("role = public");
                Promise.resolve({ redirectTo: '/' })
              }
                localStorage.setItem('jwt', data["jwt"]);
                Cookies.set('jwt', data["jwt"]);
                
            });
    }
    if (type === AUTH_LOGOUT) {
        localStorage.removeItem('jwt');
        Cookies.remove('jwt');
        return Promise.resolve();
    }
    if (type === AUTH_ERROR) {
        const status  = params.status;
        if (status === 401 || status === 403) {
            localStorage.removeItem('jwt');
            Cookies.remove('jwt');
            return Promise.reject();
        }
        return Promise.resolve();
    }
    if (type === AUTH_CHECK) {
        const check_auth = Cookies.get('jwt') || localStorage.getItem('jwt');
        return check_auth ? Promise.resolve() : Promise.reject();
    }
    if (type === AUTH_GET_PERMISSIONS) {
        const role = Cookies.get('jwt') || localStorage.getItem('jwt');
        return role ? Promise.resolve() : Promise.reject();
    }
    return Promise.resolve();
};