import React from 'react';
import { Filter, SelectInput, List, Datagrid, TextField, EmailField, ReferenceField, DateField, URLField, EditButton, Create, SimpleForm, TextInput, DateInput, ReferenceInput } from 'react-admin';
import { MyUrlField } from './MyUrlField';

const KeywordFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Search" source="keyword_name" alwaysOn />
        {/* <ReferenceInput label="Keyword_name" source="Keyword_name" reference="keyword_name" allowEmpty>
            <SelectInput optionText="name" />
        </ReferenceInput> */}
    </Filter>
);

export const KeywordList = props => (
    <List filters={<KeywordFilter />} {...props}>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <MyUrlField source="keyword_name" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            {/* <ReferenceField source="keyword_id" reference="keywords"><TextField source="id" /></ReferenceField> */}
            <ReferenceField source="designation_id" reference="designations"><TextField source="id" /></ReferenceField>
            <EditButton />
        </Datagrid>
    </List>
);


export const KeywordCreate = props => (
    <Create {...props}>
        <SimpleForm>
        <TextInput source="id" />
            <TextInput source="keyword_name" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            <ReferenceInput source="keyword_id" reference="keywords"><TextField source="id" /></ReferenceInput>
            <ReferenceInput source="designation_id" reference="designations"><TextField source="id" /></ReferenceInput>
        </SimpleForm>
    </Create>
);