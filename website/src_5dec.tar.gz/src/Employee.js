import React from 'react';
import { List, Datagrid, TextField, DateField, NumberField, EditButton, ReferenceField, EmailField, SimpleList, Create, SimpleForm, TextInput, ReferenceInput, DateInput } from 'react-admin';

export const EmployeeList = (props) => {

    return (
    <List {...props}>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <EmailField source="email" />
            <TextField source="firstName" />
            <TextField source="lastName" />
            <TextField source="password" />
            <DateField source="dateOfBirth" />
            <TextField source="reporterName" />
            <DateField source="joiningDate" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            <ReferenceField source="employee_id" reference="employees"><TextField source="id" /></ReferenceField>
            {/* <TextField source="joining_date" />
            <TextField source="employeedesignation" />
            <TextField source="first_name" />
            <TextField source="last_name" />
            <TextField source="dob" />
            <TextField source="reporter_name" /> */}
            <EditButton />
        </Datagrid>
    </List>
    );
}

export const EmployeeCreate = props => (
    <Create {...props}>
        <SimpleForm>
        <TextInput source="id" />
            <EmailField source="email" />
            <TextInput source="firstName" />
            <TextInput source="lastName" />
            <TextInput source="password" />
            <DateField source="dateOfBirth" />
            <TextInput source="reporterName" />
            <DateField source="joiningDate" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            {/* <ReferenceInput source="employee_id" reference="employees"><TextField source="id" /></ReferenceInput> */}
            {/* <TextInput source="joining_date" />
            <TextInput source="employeedesignation" />
            <TextInput source="first_name" />
            <TextInput source="last_name" />
            <DateInput source="dob" />
            <TextInput source="reporter_name" /> */}
        </SimpleForm>
    </Create>
);

