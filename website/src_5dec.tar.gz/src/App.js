import React from 'react';
import { Admin } from 'react-admin';
import { Resource, ListGuesser, EditGuesser } from 'react-admin';
import './App.css';
// import jsonServerProvider from 'ra-data-json-server';
// import simpleRestProvider from './ra-strapi-rest';
import Strapi from 'strapi-sdk-javascript/build/main';
import strapiDataProvider from 'ra-dp-strapi';
import { KeywordList, KeywordCreate } from './keywords';
import { EmpdesignationList, EmpdesignationCreate } from './empdesignation';
import { OpiniontableList, OpinionCreate } from './opiniontable';
import { EmployeeList, EmployeeCreate } from './Employee';
import Dashboard from './Dashboard';
import { UserList, UserCreate } from './UserList';
import authProvider from "./authProvider";
import MyLoginPage from './MyLoginPage';
function App() {
  const apiUrl = 'http://192.168.2.87:1337';
  const strapi = new Strapi(apiUrl);
  const App = () =>( <Admin dashboard={Dashboard} loginPage={MyLoginPage} authProvider={authProvider}  dataProvider={strapiDataProvider(strapi)}>
    <Resource name="keywords" list={KeywordList} edit={EditGuesser} create={KeywordCreate} />
    {/* <Resource name="employees" list={EmployeeList} edit={EditGuesser} create={EmployeeCreate} /> */}
    <Resource name="Empdesignations" list={EmpdesignationList} edit={EditGuesser} create={EmpdesignationCreate} />
    <Resource name="Opiniontables" list={OpiniontableList} edit={EditGuesser} create={OpinionCreate} />
    <Resource name="users" list={UserList} edit={EditGuesser} create={UserCreate} />
    </Admin>
  )
  return (
    <div className="App">
      <header className="App-header">
     <App /> 
      </header>
    </div>
  );
}
export default App;