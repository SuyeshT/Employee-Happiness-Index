import React from 'react';
import { Login, LoginForm } from 'react-admin';
import { withStyles } from '@material-ui/core';

const styles = ({
    main: { background: '#DCDCDC' },
    avatar: {
        background: 'url()',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'contain',
        height: 80,
       
    },
    icon: { display: 'block' },
});

const CustomLoginForm = withStyles({
    button: { background: '#F15922' },
})(LoginForm);

const CustomLoginPage = props => (
    <Login
        loginForm={<CustomLoginForm />}
        {...props}
    />
);

export default withStyles(styles)(CustomLoginPage);