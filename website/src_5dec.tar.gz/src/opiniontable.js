import React from 'react';
import { Filter, List, Datagrid, TextField, DateField, NumberField, EditButton, Create, TextInput, NumberInput, SimpleForm } from 'react-admin';

const OpinionFilter = (props) => (
    <Filter {...props}>
        <TextInput label="Search" source="comment" alwaysOn />
    </Filter>
);


export const OpiniontableList = props => (
    <List filters={<OpinionFilter />} {...props}>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <NumberField source="rating" />
            <TextField source="comment" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            <TextField source="keywordid.undefined" />
            <TextField source="userid.undefined" />
            <TextField source="valuerid.undefined" />
            <EditButton />
        </Datagrid>
    </List>
);


export const OpinionCreate = props => (
    <Create {...props}>
        <SimpleForm>
        <TextInput source="id" />
            <NumberInput source="rating" />
            <TextInput source="comment" />
            <DateField source="created_at" />
            <DateField source="updated_at" />
            <TextInput source="keywordid.undefined" />
            <TextInput source="userid.undefined" />
            <TextInput source="valuerid.undefined" />
        </SimpleForm>
    </Create>
);